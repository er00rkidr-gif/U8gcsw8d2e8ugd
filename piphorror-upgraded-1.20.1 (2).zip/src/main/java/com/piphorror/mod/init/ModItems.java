package com.piphorror.mod.init;

import com.piphorror.mod.PipHorrorMod;
import net.minecraft.world.item.Item;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
        DeferredRegister.create(ForgeRegistries.ITEMS, PipHorrorMod.MOD_ID);

    public static final RegistryObject<Item> PIP_SPAWN_EGG = ITEMS.register(
        "pip_spawn_egg",
        () -> new ForgeSpawnEggItem(ModEntities.PIP, 0x9AD3C0, 0x9B8BB8, new Item.Properties())
    );
}
