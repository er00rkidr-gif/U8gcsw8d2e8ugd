package com.piphorror.mod.client.model;

import com.piphorror.mod.entity.PipEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class PipModel extends GeoModel<PipEntity> {
    @Override
    public ResourceLocation getModelResource(PipEntity animatable) {
        if (animatable.isFakePip()) {
            return new ResourceLocation("piphorror", "geo/pip_fake.geo.json");
        }
        return new ResourceLocation("piphorror", "geo/pip.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(PipEntity animatable) {
        if (animatable.isFakePip()) {
            return new ResourceLocation("piphorror", "textures/entity/pip_fake.png");
        }
        return new ResourceLocation("piphorror", "textures/entity/pip_horror.png");
    }

    @Override
    public ResourceLocation getAnimationResource(PipEntity animatable) {
        return new ResourceLocation("piphorror", "animations/pip.animation.json");
    }
}
